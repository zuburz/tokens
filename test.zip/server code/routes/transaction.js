const express = require('express');
const { makePayment } = require('../controllers/transaction');
const { protect, authorize } = require('../middlewares/auth');



const router = express.Router({ mergeParams: true });



// router.use(protect);
router.post('/', makePayment);

module.exports = router;