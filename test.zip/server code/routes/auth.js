const express = require('express');

const { register, login,verifyReferalCode } = require('../controllers/auth');

const { protect, authorize } = require('../middlewares/auth');
const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.post('/verifyReferalCode', verifyReferalCode);

module.exports = router;
