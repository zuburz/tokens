const express = require('express');
const { whitePaper } = require('../controllers/whitepaper');
const { protect, authorize } = require('../middlewares/auth');



const router = express.Router({ mergeParams: true });



// router.use(protect);
router.post('/', whitePaper);

module.exports = router;