const mongoose = require('mongoose');


const TransactionSchema = new mongoose.Schema(
    {

      paymentMethod: {
        type: String,
      },
      paymentCurrency: {
        type: String,
      },
      tokenPrice: {
        type: Number,
      },
      totalAmount: {
        type: Number,
      },
      totalToken: {
        type: Number,
      },
      toAddress: {
        type: String,
      },
      referalCode: {
        type: String,
      },
      lockingTime: {
        type: String,
      },
      status: {
        type: String,
        default:'Processs'
      },
    },
    {
      timestamps: true,
    }
  );

  
module.exports = mongoose.model('Transaction', TransactionSchema);