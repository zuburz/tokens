const nodemailer = require('nodemailer');

exports.sendEmail = async (options) => {
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    secure: true,
    auth: {
      user: process.env.SMTP_EMAIL,
      pass: process.env.SMTP_PASSWORD,
    },
  });
  const message = { 
    from: process.env.FROM_EMAIL,
    to: options.email,
    subject: 'Email Verification',
    html: `
      <h2>Please click on the link below to verify your email.</h2>
      <a href=${process.env.CLIENT_SUCCESS_URL}/verifyemail/${options.token}>Click here to verify your email address.</a>
    `,
  };
  const info = await transporter.sendMail(message);
};