
var Web3 = require('web3');
//const random = require('random')
//const Tx = require('ethereumjs-tx')
const Tx = require('ethereumjs-tx').Transaction
//const tx = new Tx(txObject, {chain:'ropsten', hardfork: 'petersburg'})
//const timestampToDate = require('.timestampToDate');
var Accounts = require('web3-eth-accounts');

//import Common from 'ethereumjs-common'

const Common = require('ethereumjs-common')
/*c
const BSC_MAIN = Common.forCustomChain(
  'mainnet', {
      name: 'bnb',
      networkId: 56, 
      chainId: 56
  }, 
  'petersburg'
)*/
//let fromAddress = '0x1cF05Bf1191e7CB0b093DE86fC7BD4fa0EA13e80' 
const common = Common.default.forCustomChain('mainnet', {
  name: 'bnb',
  networkId: 56,
  chainId: 56
}, 'petersburg');




let tokenAddress = '0x1cF05Bf1191e7CB0b093DE86fC7BD4fa0EA13e80'
var web3 = new Web3('https://bsc-dataseed1.binance.org:443');
//var accounts = [ '0x115aE3AFEE2cec1bF60CB620F4B729e874256015', '0x784a635dE41276Da3f43e8407F94c4951210941A', '0xaf85E75E26D21E3917a4E29FBd69E23dF784949c','0x4738d68937648F9DA25013a4cA2b1540Ae0FCf16','0x8290454d388BD197c496883D85e8b09Bd2bBc542','0x91A4e4A201D16f6DCe56ABc46D553eb97597c68f','0x8d1f89A1f61A964ba70d696Db7902aB0bBbdF671','0x6204FED16E4cc20296b07437F0706113EDcF7d8E','0xf8C69280515367017190EdE781D2A7Fb9123ABa6' ,'0x432aBc8df56B7eFb6EDcAb629487BEE481eC54ac','0x69B1BC23f8fC642D9D8Fc53f633c8736AE4c0423'];
//console.log(accounts[9],' accounts')

//var key = [ '06a7dd3e3f0e5382dd820e823c63b7f6f55703ab1679d6f6487006a99b0921ba', 'f065bddb16c02955046a911117fd462bcbbfeae9f1c26c77670a1738acba2cad', '25b8ffca22dc661d10278a9bc21f028f71719181a6928e6df8ed9e3bb35d2d07','5f28e10b4ae31d7bf43149bd0980d1cfbc6b2da537437e3e49fc74e374dd379d','4f6c7925a9ccb399326830df20c203905e24f38a38cd6307ce579310e7afff98','250681ec9607585f0bc61e6615092de8d112e85362b2d0a82fb7bdb073d86622','a47a2c9ed498693beecf23d2c0b7ab820709a7620f45cc9e3c3c7ff769aecbfd','f2938202e208e09a0ebc452e68460f8046f03f7bea4882fce36e04f9ebc85ee2','4c7b60b4c5acc798bc4f8773b940c2ca125b1da96768d0f7c8ca7e2cc471cde5','2a3283cdae0094f46a962434dcc0b2b867f4e1f6fd5008e46c05846a6f932b0f','e87b1c7c09d6c0932493c0aeb832d12699b30a8881948153010980bf53d7bdf7' ];
//console.log(key[9],' key')
let contractABI = [{ "inputs": [], "payable": false, "stateMutability": "nonpayable", "type": "constructor" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "_owner", "type": "address" }, { "indexed": true, "internalType": "address", "name": "_spender", "type": "address" }, { "indexed": false, "internalType": "uint256", "name": "_value", "type": "uint256" }], "name": "Approval", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "from", "type": "address" }, { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }], "name": "Burn", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "from", "type": "address" }, { "indexed": true, "internalType": "address", "name": "to", "type": "address" }, { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }], "name": "Transfer", "type": "event" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "", "type": "address" }], "name": "LockList", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "Account", "type": "address" }, { "internalType": "uint256", "name": "amount", "type": "uint256" }], "name": "LockTokens", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "", "type": "address" }], "name": "LockedTokens", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "Account", "type": "address" }], "name": "UnLockTokens", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "Account", "type": "address" }, { "internalType": "bool", "name": "mode", "type": "bool" }], "name": "UserLock", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "_owner", "type": "address" }, { "internalType": "address", "name": "_spender", "type": "address" }], "name": "allowance", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "_spender", "type": "address" }, { "internalType": "uint256", "name": "_value", "type": "uint256" }], "name": "approve", "outputs": [{ "internalType": "bool", "name": "success", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "_spender", "type": "address" }, { "internalType": "uint256", "name": "_value", "type": "uint256" }, { "internalType": "bytes", "name": "_extraData", "type": "bytes" }], "name": "approveAndCall", "outputs": [{ "internalType": "bool", "name": "success", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [{ "internalType": "address", "name": "", "type": "address" }], "name": "balanceOf", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "uint256", "name": "_value", "type": "uint256" }], "name": "burn", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "Account", "type": "address" }, { "internalType": "uint256", "name": "_value", "type": "uint256" }], "name": "burnFrom", "outputs": [{ "internalType": "bool", "name": "success", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": true, "inputs": [], "name": "decimals", "outputs": [{ "internalType": "uint8", "name": "", "type": "uint8" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "name", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "owner", "outputs": [{ "internalType": "address", "name": "", "type": "address" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "symbol", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": true, "inputs": [], "name": "totalSupply", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "_to", "type": "address" }, { "internalType": "uint256", "name": "_value", "type": "uint256" }], "name": "transfer", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "_from", "type": "address" }, { "internalType": "address", "name": "_to", "type": "address" }, { "internalType": "uint256", "name": "_value", "type": "uint256" }], "name": "transferFrom", "outputs": [{ "internalType": "bool", "name": "success", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "internalType": "address", "name": "newOwner", "type": "address" }], "name": "transferOwnership", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }]

exports.transection = (fromAddress, toAddress, amount, privateKey) => {
  return new Promise(async (resolve, reject) => {
    try {
      let private = await Buffer.from(privateKey, 'hex')
      let contract = await new web3.eth.Contract(contractABI, tokenAddress, { from: fromAddress })
      amount1 = await web3.utils.toWei(amount.toString(), 'ether');
      count = await web3.eth.getTransactionCount(fromAddress)
      let rawTransaction = {
        'from': await fromAddress,
        'gasPrice': await web3.utils.toHex(web3.utils.toWei('5', 'gwei')),
        'gasLimit': await web3.utils.toHex(90000),
        'to': await tokenAddress,
        'value': 0x0,
        'data': await contract.methods.transfer(toAddress, amount1).encodeABI(),
        'nonce': await web3.utils.toHex(count)
      }
      let transaction = new Tx(rawTransaction, {
        common
      })
      trx = await transaction.sign(private)
      hash = await web3.eth.sendSignedTransaction('0x' + transaction.serialize().toString('hex'))
     return  resolve({ status: 200, hash: { trx, hash } })
    } catch (error) {
      return resolve({ status: 401, hash: {} })
    }
  });



}

// transection('0x115aE3AFEE2cec1bF60CB620F4B729e874256015', '0x784a635dE41276Da3f43e8407F94c4951210941A', 10, '06a7dd3e3f0e5382dd820e823c63b7f6f55703ab1679d6f6487006a99b0921ba')