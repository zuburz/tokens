const asyncHandler = require('../middlewares/async');
const ErrorResponse = require('../utils/errorResponse');




exports.whitePaper = asyncHandler(async (req, res, next) => {

 
});
