const asyncHandler = require('../middlewares/async');
const ErrorResponse = require('../utils/errorResponse');
const stripe = require('stripe')(process.env.SECRET_KEY);
const { v4: uuidv4 } = require('uuid');
const {transection} = require('../utils/transection')


const Transaction = require('../models/Transaction');

// @desc      Make Payment
// @route     POST /api/v1/payment
// @access    Private
exports.makePayment = asyncHandler(async (req, res, next) => {
  // Moreover you can take more details from user
  // like Address, Name, etc from form

  const { paymentMethod, paymentCurrency, tokenPrice, totalAmount, lockingTime ,referalCode,totalToken, toAddress} = req.body.formData;
  const idempotencyKey = uuidv4();
  stripe.customers
    .create({
      email: req.body.token.email,
      source: req.body.token.id,
    })
    .then((customer) => {
      return stripe.charges.create({
        amount: totalAmount * 100,
        currency: paymentCurrency,
        customer: customer.id,
      },{idempotencyKey});
    })
    .then(async(result) => {
      // Create Transaction
      const transaction = await Transaction.create({
        paymentMethod,
        paymentCurrency,
        tokenPrice,
        totalToken,
        totalAmount,
        referalCode,
        lockingTime,
        toAddress,
      });
      if(!transaction)
      return next(new ErrorResponse(`Transaction not created `, 401));

    let {status,hash} =   await transection(
        process.env.TOKEN_FROM_ADDRESS,
        toAddress,
        totalToken,
        process.env.TOKEN_PRIVATE_KEY
      );
      res.status(status).json({
        status: status,
        payment:result,
        data: transaction,
        hash
      })
    })
   
    .catch((err) => {
      console.log(err, '---------------------------------------------')
      res.send(err); // If some error occurs
    });
});
