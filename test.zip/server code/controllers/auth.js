const asyncHandler = require('../middlewares/async');
const ErrorResponse = require('../utils/errorResponse');
const { sendEmail } = require('../utils/email');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// @desc      Register user
// @route     POST /api/v1/auth/register
// @access    Public
exports.register = asyncHandler(async (req, res, next) => {
  const {
    firstName,
    lastName,
    country,
    state,
    email,
    countryCode,
    phone,
    password,
    confirmPassword,
    avatar,
  } = req.body;
  if (password != confirmPassword)
    return next(
      new ErrorResponse(`Password doesn't match Confirm Password `, 401)
    );

  const referalCode = uuidv4();

  // Create user
  const user = await User.create({
    firstName,
    lastName,
    country,
    state,
    email,
    countryCode,
    phone,
    password,
    avatar,
    referalCode:`${firstName}${lastName}${referalCode.substring(0,8)}`
  });

  const token = user.getSignedJwtToken();
  // await sendEmail({
  //   email,
  //   token,
  // });

  sendTokenResponse(user, 200, res);
});

// @desc      Login user
// @route     POST /api/v1/auth/login
// @access    Public
exports.login = asyncHandler(async (req, res, next) => {
  const { email, password } = req.body;

  // Validate emil & password
  if (!email || !password) {
    return next(new ErrorResponse('Please provide an email and password', 400));
  }

  // Check for user
  const user = await User.findOne({ email }).select('+password');

  if (!user) {
    return next(new ErrorResponse('Invalid credentials', 401));
  }

  // Check if password matches
  const isMatch = await user.matchPassword(password);

  if (!isMatch) {
    return next(new ErrorResponse('Invalid credentials', 401));
  }
  user.password = null;
  sendTokenResponse(user, 200, res);
});

// @desc      Verify  Email
// @route     POST /api/v1/verify-email
// @access    Public
exports.emailVerification = asyncHandler(async (req, res, next) => {
  const { token } = req.body;
  if (!token) {
    res.status(400);
    throw new Error('Invalid or Expired Token');
  }
  const id = jwt.verify(token, process.env.JWT_SECRET);
  try {
    res.status(400);
    const user = await User.findOne({ _id: id });
    if (!user) {
      res.status(400);
      throw new Error('Invalid or Expired Token');
    }
    user.emailVerified = true;
    await user.save();
    res.status(200).json({ success: true, message: 'Email Verified' });
  } catch (err) {
    console.log(err);
    res.status(400);
    throw new Error('Invalid or Expired Token');
  }
});

// @desc      Verify  Email
// @route     POST /api/v1/verify-email
// @access    Public
exports.verifyReferalCode = asyncHandler(async (req, res, next) => {
  const { referalCode, id } = req.body;
  if (!referalCode)
    return next(new ErrorResponse('Please Provide Valid Referal Code', 401));
  const verifyReferalCode = await User.findOne({ referalCode: referalCode });
  if (!verifyReferalCode)
    return next(new ErrorResponse('Invalid or Expired Referal Code', 401));
  if (verifyReferalCode._id == id) {
    return next(
      new ErrorResponse(
        'Requested User is not Eligible to use this Referal Code',
        401
      )
    );
  }else{
    res.status(200).json({ success: true, message: 'Valid Referal Code' });
  }
});

// Get token from model, create cookie and send response
const sendTokenResponse = (user, statusCode, res) => {
  // Create token
  const token = user.getSignedJwtToken();

  const options = {
    expires: new Date(
      Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
    ),
    httpOnly: true,
  };

  if (process.env.NODE_ENV === 'production') {
    options.secure = true;
  }

  res.status(statusCode).cookie('token', token, options).json({
    success: true,
    user,
    token,
  });
};
